import numpy as np
import cmath
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import random
import pandas as pd
from scipy.integrate import odeint
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.collections import LineCollection
from scipy.stats import norm
import seaborn as sns
from sklearn.mixture import GaussianMixture
import matplotlib
from matplotlib.ticker import MaxNLocator
from scipy.interpolate import interp1d
import matplotlib.ticker as mticker
import os
#%matplotlib inline

# 定义 'output' 目录
output_directory = './output'
# 对尺寸和 dpi参数进行调整
plt.rcParams['figure.dpi'] = 300
# 字体调整
plt.rcParams['font.family'] = 'sans-serif'
#plt.rcParams['font.sans-serif'] = ['Arial']  # 如果要显示中文字体,则在此处设为：simhei,Arial Unicode MS
#plt.rcParams['font.weight'] = 'light'
plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号显示
plt.rcParams['axes.titlesize'] = 12  # 标题字体大小
plt.rcParams['axes.labelsize'] = 10  # 坐标轴标签字体大小
plt.rcParams['xtick.labelsize'] = 8  # x轴刻度字体大小
plt.rcParams['ytick.labelsize'] = 8  # y轴刻度字体大小
plt.rcParams['legend.fontsize'] = 8
# 线条调整
plt.rcParams['axes.linewidth'] = 0.8#100条时linewidth1
# 刻度在内，设置刻度字体大小
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
# 设置输出格式为PDF
plt.rcParams['savefig.format'] = 'pdf'
plt.rcParams['figure.autolayout'] = True
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42

#constant induction
def propensities_bistable(x, t, k, ki, base, para_a, para_d, I):
    X1 = x[0]
    X2 = x[1]
    n = [2, 2]
    a = [base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))/(1 + (X2/k[1])**n[1]),                # X1 production
         base[1] + (para_a[1]*(I/ki[1])/(1+I/ki[1]))/(1 + (X1/k[0])**n[0]),                # X2 production
         para_d[0]*X1,                                             # protein decay
         para_d[1]*X2]                                             # protein decay
    return a

#gradual induction
def propensities_bistable_gradualinduction(x, t, k, ki, base, para_a, para_d, I):
    Tgradualinduction = 50*np.log(2)/0.02 #诱导需要50代达到终态
    if t<=Tgradualinduction:
        I = I*t/Tgradualinduction

    X1 = x[0]
    X2 = x[1]
    n = [2, 2]
    a = [base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))/(1 + (X2/k[1])**n[1]),                # X1 production
         base[1] + (para_a[1]*(I/ki[1])/(1+I/ki[1]))/(1 + (X1/k[0])**n[0]),                # X2 production
         para_d[0]*X1,                                             # protein decay
         para_d[1]*X2]                                             # protein decay
    return a

#with delay
def direct_method_withdelay(propensity_fcn, tspan, x0, delay, k, ki, base, para_a, para_d, I):
    # Initialize
    stoich_matrix = np.array([[1, 0],  # X1 production
                              [0, 1],  # X2 production
                              [-1, 0],  # X1 decay
                              [0, -1]])  # X2 decay
    num_species = stoich_matrix.shape[1]
    MAX_OUTPUT_LENGTH = round(tspan[1]*0.02/np.log(2)*1000)
    T = np.zeros(MAX_OUTPUT_LENGTH)
    X = np.zeros((MAX_OUTPUT_LENGTH, num_species))
    td = np.zeros(MAX_OUTPUT_LENGTH)
    mu = np.zeros(MAX_OUTPUT_LENGTH)
    T[0] = tspan[0]
    X[0, :] = x0
    window_size = round(delay[1] / 0.01)  # Define window size

    # Main loop
    rxn_count = 1

    while T[rxn_count - 1] < tspan[1]:

        if rxn_count >= MAX_OUTPUT_LENGTH:
            t = T[:rxn_count - 1]
            x = X[:rxn_count - 1, :]
            print('Number of reaction events exceeded the number pre-allocated. Simulation terminated prematurely.')
            return t, x

        a = propensity_fcn(X[rxn_count - 1, :], T[rxn_count - 1], k, ki, base, para_a, para_d, I)
        a0 = np.sum(a)
        u = np.random.rand(2)
        tau = -np.log(u[0]) / a0

        # Check whether there are delayed reactions scheduled within time interval
        # Define the window for td
        start_index = max(0, rxn_count - window_size)
        end_index = rxn_count

        ind = (td[start_index:end_index] > T[rxn_count - 1]) & (td[start_index:end_index] <= T[rxn_count - 1] + tau)
        mintd = np.min(td[start_index:end_index][ind]) if np.any(ind) else None

        if mintd:
            T[rxn_count] = mintd
            X[rxn_count, :] = X[rxn_count - 1, :] + stoich_matrix[1, :]
            rxn_count += 1
            continue

        mu[rxn_count] = np.digitize(u[1] * a0, np.cumsum(a))

        if mu[rxn_count] == 1:
            td[rxn_count] = T[rxn_count - 1] + delay[1]
            X[rxn_count, :] = X[rxn_count - 1, :]
            T[rxn_count] = T[rxn_count - 1] + tau
            rxn_count += 1
            continue

        # Update time and carry out reaction mu
        T[rxn_count] = T[rxn_count - 1] + tau
        X[rxn_count, :] = X[rxn_count - 1, :] + stoich_matrix[int(mu[rxn_count]), :]
        rxn_count += 1

    # Return simulation time course
    t = T[:rxn_count - 1]
    x = X[:rxn_count - 1, :]
    # print(rxn_count)
    if t[-1] > tspan[1]:
        t[-1] = tspan[1]
        x[-1, :] = X[rxn_count - 1, :]

    return t, x

#without delay
def direct_method_withoutdelay(propensity_fcn, tspan, x0, delay, k, ki, base, para_a, para_d, I):
    # Initialize
    stoich_matrix = np.array([[1, 0],  # X1 production
                              [0, 1],  # X2 production
                              [-1, 0],  # X1 decay
                              [0, -1]])  # X2 decay
    num_species = stoich_matrix.shape[1]
    MAX_OUTPUT_LENGTH = round(tspan[1]*0.02/np.log(2)*1000)
    T = np.zeros(MAX_OUTPUT_LENGTH)
    X = np.zeros((MAX_OUTPUT_LENGTH, num_species))
    mu = np.zeros(MAX_OUTPUT_LENGTH)
    T[0] = tspan[0]
    X[0, :] = x0

    # Main loop
    rxn_count = 1
    while T[rxn_count - 1] < tspan[1]:

        if rxn_count >= MAX_OUTPUT_LENGTH:
            t = T[:rxn_count - 1]
            x = X[:rxn_count - 1, :]
            print('Number of reaction events exceeded the number pre-allocated. Simulation terminated prematurely.')
            return t, x

        a = propensity_fcn(X[rxn_count - 1, :], T[rxn_count - 1], k, ki, base, para_a, para_d, I)
        a0 = np.sum(a)
        u = np.random.rand(2)
        tau = -np.log(u[0]) / a0

        mu[rxn_count] = np.digitize(u[1] * a0, np.cumsum(a))

        # Update time and carry out reaction mu
        T[rxn_count] = T[rxn_count - 1] + tau
        X[rxn_count, :] = X[rxn_count - 1, :] + stoich_matrix[int(mu[rxn_count]), :]
        rxn_count += 1

    # Return simulation time course
    t = T[:rxn_count - 1]
    x = X[:rxn_count - 1, :]
    # print(rxn_count)
    if t[-1] > tspan[1]:
        t[-1] = tspan[1]
        x[-1, :] = X[rxn_count - 1, :]

    return t, x


# 定义插值函数
def check_conditions(t, x, check_times):
    conditions = {time: None for time in check_times}

    # 插值函数
    interp_x0 = interp1d(t, x[:, 0], fill_value="extrapolate")  # fill_value="extrapolate"：如果请求的插值时间点在原始数据范围之外，使用外推来估计值。
    interp_x1 = interp1d(t, x[:, 1], fill_value="extrapolate")

    for time in check_times:
        x0_at_time = interp_x0(time)
        x1_at_time = interp_x1(time)
        conditions[time] = x0_at_time - x1_at_time

    return conditions


# 出图：时序图、相图、概率分布图、xhigh比例图
def plot_trajectory(method_fcn, propensity_fcn, num_path, tspan, x0, delay, k, ki, base, para_a, para_d, I):
    # 创建第一张图：时序轨迹
    fig1, ax1 = plt.subplots(num=1, figsize=(2.6, 1.4), dpi=300)
    # 创建第二张图：流场中的轨迹
    fig2, ax2 = plt.subplots(num=2, figsize=(2.8, 2.3), dpi=300)
    # 创建第三四张图：finalpositon末态分布
    fig3, ax3 = plt.subplots(num=3, figsize=(2.45, 1.1), dpi=300)
    fig4, ax4 = plt.subplots(num=4, figsize=(2.45, 1.1), dpi=300)
    # 创建第五六张图：Xhigh比例
    fig5 = plt.figure(num=5, figsize=(2.8, 2.6), dpi=300)
    ax5 = fig5.add_subplot(111, projection='3d')
    fig6, ax6 = plt.subplots(num=6, figsize=(2.6, 2.2), dpi=300)

    # 流形图初始化
    a = np.arange(0, 600, 1)
    b = np.arange(0, 600, 1)
    X, Y = np.meshgrid(a, b)
    n = [2, 2]
    U = base[0] + (para_a[0] * (I / ki[0]) / (1 + I / ki[0])) / (1 + (Y / k[1]) ** n[1]) - para_d[0] * X
    V = base[1] + (para_a[1] * (I / ki[1]) / (1 + I / ki[1])) / (1 + (X / k[0]) ** n[0]) - para_d[1] * Y

    # 记录状态
    check_times = tspan[1] / 10 * np.arange(1, 10)  # 一共取十个观察点，100代则取10，20，..90代.1000代则是100,200,..900代.
    all_conditions = []
    final_positions = []
    Xhigh = []

    for n in range(num_path):
        if n % 10 == 0:
            print("path =", n)

        t, x = method_fcn(propensity_fcn, tspan, x0, delay, k, ki, base, para_a, para_d, I)

        # 记录每一条在十个时刻的状态
        final_position = x[-1, :]
        final_positions.append(final_position)
        conditions = check_conditions(t, x, check_times)
        all_conditions.append(conditions)

        # 绘制第一张图：t-xy图
        interval = 50
        t_reduced = t[::interval]
        x_reduced = x[::interval]
        if x[-1, 0] > x[-1, 1]:
            ax1.plot(t_reduced * 0.02 / np.log(2), x_reduced[:, 0], color=[0.85, 0.33, 0.10],
                     linewidth=0.2)  # 100条时linewidth0.4
        else:
            ax1.plot(t_reduced * 0.02 / np.log(2), x_reduced[:, 0], color=[0.00, 0.45, 0.74], linewidth=0.2)  # 0.4

        # 绘制第二张图：相图
        ax2.streamplot(X, Y, U, V, density=0.8, linewidth=0.4, color='lightskyblue', zorder=0)  # 0.6
        colors = plt.cm.viridis_r(np.linspace(0, 1, num_path))
        points = np.array([x[:, 0], x[:, 1]]).T
        segments = np.hstack((points[:-1].reshape(-1, 2), points[1:].reshape(-1, 2))).reshape(-1, 2, 2)
        lc = LineCollection(segments, cmap='viridis_r', norm=LogNorm(vmin=0.1, vmax=tspan[1] * 0.02 / np.log(2)),
                            linewidth=0.6, zorder=1)  # 1
        lc.set_array(t * 0.02 / np.log(2))
        ax2.add_collection(lc)

    # 设置轴标签和范围
    ax1.margins(0, 0)
    ax1.set_xlabel('Generations')
    ax1.set_ylabel('x')
    ax1.set_xlim(0, tspan[1] * 0.02 / np.log(2))
    ax1.set_ylim(0, 600)
    ax1.xaxis.set_major_locator(MaxNLocator(4))
    ax1.yaxis.set_major_locator(MaxNLocator(3))

    ax2.margins(0, 0)
    cbar = plt.colorbar(lc, ax=ax2)
    cbar.set_label('Time', rotation=270)
    ax2.set_xlabel("$x$")
    ax2.set_ylabel("$y$")
    ax2.set_xlim(0, 600)
    ax2.set_ylim(0, 600)
    ax2.xaxis.set_major_locator(MaxNLocator(3))
    ax2.yaxis.set_major_locator(MaxNLocator(3))

    # 记录状态值
    final_positions = np.array(final_positions)
    conditions_matrix = np.zeros((len(check_times), num_path))
    for i, time in enumerate(check_times):
        conditions_matrix[i, :] = [condition[time] for condition in all_conditions]  # (9,100)
        count_greater_than_zero = np.sum(conditions_matrix[i, :] > 0)
        Xhigh.append(count_greater_than_zero / num_path)  # (9,1)
    finalxplusy = final_positions[:, 0] - final_positions[:, 1]
    conditions_matrix = np.vstack((conditions_matrix, finalxplusy))  # (10,100)
    finalXhigh = np.sum(finalxplusy > 0)
    Xhigh.append(finalXhigh / num_path)  # (10,1)
    print('Final X high: {}/{}'.format(finalXhigh, num_path))
    print('X high:', Xhigh)

    # 第三四张图：末态pdf
    # 绘制直方图
    ax3.hist(final_positions[:, 0], bins=60, density=True, alpha=0.75)
    # 拟合混合高斯分布曲线
    gmm = GaussianMixture(n_components=2)
    gmm.fit(final_positions[:, 0].reshape(-1, 1))
    x_vals = np.linspace(0, 600, 600).reshape(-1, 1)
    y_vals = np.exp(gmm.score_samples(x_vals)).ravel()
    ax3.plot(x_vals, y_vals, 'r-')
    # 设置坐标轴
    ax3.set_xlim(0, 600)
    ax3.set_ylim(0, 0.1)
    ax3.xaxis.set_major_locator(MaxNLocator(3))
    ax3.yaxis.set_major_locator(MaxNLocator(2))
    # ax3.text(450, 0.085, txt, bbox=dict(facecolor ='white'))
    # ax3.set_xlabel('X')
    ax3.set_ylabel('Density')

    # 绘制直方图
    ax4.hist(final_positions[:, 1], bins=60, density=True, alpha=0.75)
    # 拟合混合高斯分布曲线
    gmm = GaussianMixture(n_components=2)
    gmm.fit(final_positions[:, 1].reshape(-1, 1))
    x_vals = np.linspace(0, 600, 600).reshape(-1, 1)
    y_vals = np.exp(gmm.score_samples(x_vals)).ravel()
    ax4.plot(x_vals, y_vals, 'r-')
    # 设置坐标轴
    ax4.set_xlim(0, 600)
    ax4.set_ylim(0, 0.1)
    ax4.xaxis.set_major_locator(MaxNLocator(3))
    ax4.yaxis.set_major_locator(MaxNLocator(2))
    # ax4.text(450, 0.085, txt, bbox=dict(facecolor ='white'))
    # ax4.set_xlabel('Y')
    ax4.set_ylabel('Density')

    # 第五张图：x-y分布图
    x_vals = np.linspace(-600, 600, 600).reshape(-1, 1)
    for t in range(10):
        data_at_t = conditions_matrix[t, :].T.reshape(-1, 1)
        gmm = GaussianMixture(n_components=2)
        gmm.fit(data_at_t)
        y_vals = np.exp(gmm.score_samples(x_vals)).ravel()
        hist, bins = np.histogram(data_at_t, bins=60, density=True)
        bin_centers = (bins[:-1] + bins[1:]) / 2
        ax5.bar(bin_centers, hist, width=np.diff(bins), zs=(t + 1) * round(tspan[1] * 0.002 / np.log(2)), zdir='y',
                alpha=0.3)
        ax5.plot(x_vals.flatten(), y_vals, zs=(t + 1) * round(tspan[1] * 0.002 / np.log(2)), zdir='y', linewidth=0.8)
    ax5.set_xlabel('x-y')
    ax5.set_ylabel('Generations')
    ax5.set_zlabel('Density')
    ax5.xaxis.set_major_locator(MaxNLocator(5))
    ax5.yaxis.set_major_locator(MaxNLocator(5))
    ax5.zaxis.set_major_locator(MaxNLocator(4))

    # 第六张图：Xhigh比例图
    check_times_gen = check_times * 0.02 / np.log(2)
    check_times_gen = np.append(check_times_gen, tspan[1] * 0.02 / np.log(2))
    width = tspan[1] * 0.02 / np.log(2) * 0.06
    bars = ax6.bar(check_times_gen, Xhigh, width, color='c', edgecolor='black')
    for bar in bars:
        yval = bar.get_height()
        ax6.text(bar.get_x() + bar.get_width() / 2.0, yval, f'{yval:.4f}', ha='center', va='bottom', fontsize=3.5)
    ax6.set_xlabel('Generations')
    ax6.set_ylabel('X high')
    # ax.set_xlim(0, 120)
    ax6.set_ylim(0, 1)
    ax6.xaxis.set_major_locator(MaxNLocator(6))
    ax6.yaxis.set_major_locator(MaxNLocator(5))
    # plt.grid(True)

    return fig1, fig2, fig3, fig4, fig5, fig6

#parameters
x_initial = np.array([0, 0])  # X, Y protein
para_d = np.array([0.02, 0.02])  #min^-1
base = np.array([0.1, 0.1])
I = 1.0
n = [2, 2]
k = [100, 100]
#主要改
tspan = [0, 100*np.log(2)/0.02]  # min
num_path = 2000
para_a = np.array([10, 10])  #molecules/min
ki = np.array([0.1, 0.1])
delay = [0,0.5*np.log(2)/0.02]

#plot figures
#Options：direct_method_withdelay / direct_method_withoutdelay / propensities_bistable / propensities_bistable_gradualinduction
fig1,fig2,fig3,fig4,fig5,fig6=plot_trajectory(direct_method_withdelay, propensities_bistable_gradualinduction, num_path, tspan, x_initial, delay, k, ki, base, para_a, para_d, I)
file_path1= os.path.join(output_directory, 'withdelay_gradual_100gen_2000num_de05_txy.pdf')
file_path2= os.path.join(output_directory, 'withdelay_gradual_100gen_2000num_de05_phase.png')
file_path3= os.path.join(output_directory, 'withdelay_gradual_100gen_2000num_de05_pdfX.pdf')
file_path4= os.path.join(output_directory, 'withdelay_gradual_100gen_2000num_de05_pdfY.pdf')
file_path5= os.path.join(output_directory, 'withdelay_gradual_100gen_2000num_de05_density.pdf')
file_path6= os.path.join(output_directory, 'withdelay_gradual_100gen_2000num_de05_Xhigh.pdf')
fig1.savefig(file_path1)#fig1.savefig('withoutdelay_stage_ki0.2a1514_txy.pdf')
fig2.savefig(file_path2)
fig3.savefig(file_path3)
fig4.savefig(file_path4)
fig5.savefig(file_path5)
fig6.savefig(file_path6)
plt.show()

