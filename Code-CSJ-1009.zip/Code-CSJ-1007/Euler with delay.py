import numpy as np
import cmath
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import random
import pandas as pd
from matplotlib import pyplot
from scipy.integrate import odeint
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.collections import LineCollection
from scipy.stats import norm
import seaborn as sns
from sklearn.mixture import GaussianMixture
import matplotlib
from matplotlib.ticker import MaxNLocator
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
#%matplotlib inline

# 对尺寸和 dpi参数进行调整
plt.rcParams['figure.dpi'] = 300
# 字体调整
plt.rcParams['font.sans-serif'] = ['Arial']  # 如果要显示中文字体,则在此处设为：simhei,Arial Unicode MS
plt.rcParams['font.weight'] = 'light'
plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号显示
plt.rcParams['axes.titlesize'] = 12  # 标题字体大小
plt.rcParams['axes.labelsize'] = 10  # 坐标轴标签字体大小
plt.rcParams['xtick.labelsize'] = 8  # x轴刻度字体大小
plt.rcParams['ytick.labelsize'] = 8  # y轴刻度字体大小
plt.rcParams['legend.fontsize'] = 6
# 线条调整
plt.rcParams['axes.linewidth'] = 1
# 刻度在内，设置刻度字体大小
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
# 设置输出格式为PDF
plt.rcParams['savefig.format'] = 'pdf'
plt.rcParams['figure.autolayout'] = True
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42

#台阶诱导
def stepinduction(it, y, idelay, k, ki, base, para_a, para_d, I):
    br[it,0] = base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))/(1 + (y[it-idelay[1], 1]/k[1])**n[1])
    br[it,1] = base[1] + (para_a[1]*(I/ki[1])/(1+I/ki[1]))/(1 + (y[it-idelay[0], 0]/k[0])**n[0])
    dydt[it,0] = br[it,0]-para_d[0]*y[it, 0]
    dydt[it,1] = br[it,1]-para_d[1]*y[it, 1]
    return dydt[it,:],br[it,:]

#梯度诱导
def gradualinduction(it, y, idelay, k, ki, base, para_a, para_d, I):
    treal=it*dt
    if treal<=Tgradualinduction:
        I = I*treal/Tgradualinduction
    br[it,0] = base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))/(1 + (y[it-idelay[1], 1]/k[1])**n[1])
    br[it,1] = base[1] + (para_a[1]*(I/ki[1])/(1+I/ki[1]))/(1 + (y[it-idelay[0], 0]/k[0])**n[0])
    dydt[it,0] = br[it,0]-para_d[0]*y[it, 0]
    dydt[it,1] = br[it,1]-para_d[1]*y[it, 1]
    return dydt[it,:],br[it,:]

#台阶诱导
def stepinductionpro(it, y, idelay, k, ki, base, para_a, para_d, I):
    br[it,0] = base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))
    dydt[it,0] = br[it,0] - para_d[0]*y[it, 0]
    br[it,1] = 0
    dydt[it,1] = 0
    return dydt[it,:],br[it,:]

#梯度诱导
def gradualinductionpro(it, y, idelay, k, ki, base, para_a, para_d, I):
    treal=it*dt
    if treal<=Tgradualinduction:
        I = I*treal/Tgradualinduction
    br[it,0] = base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))
    dydt[it,0] = br[it,0] - para_d[0]*y[it, 0]
    br[it,1] = 0
    dydt[it,1] = 0
    return dydt[it,:],br[it,:]

#解DDE
def edde(propensity_fcnpro,propensity_fcn,delay,tend,dt, k, ki, base, para_a, para_d, I):
    y[:, 0] = hist[0]
    y[:, 1] = hist[1]
    # 处理(0, idelay[1])时间段
    for it in range(0, idelay[1]):
        dydt[it,:],br[it,:] = propensity_fcnpro(it, y, idelay, k, ki, base, para_a, para_d, I)
        y[it + 1, 0] = y[it, 0] + dt * dydt[it, 0]  # 更新y的第一列
    for it in range(idelay[1], itend-1):
        dydt[it,:],br[it,:] = propensity_fcn(it, y, idelay, k, ki, base, para_a, para_d, I)
        y[it + 1, :] = y[it, :] + dt * dydt[it,:]
    return y,dydt,br


# 出图：时序图、相图、概率分布图
def plot_productionrate(propensity_fcnpro, propensity_fcn, delay, tend, dt, k, ki, base, para_a, para_d, I):
    # 创建第一张图：时序轨迹
    fig1, ax1 = plt.subplots(num=1, figsize=(2.7, 1.2), dpi=300)
    # 创建第二张图：流场中的轨迹
    fig2, ax2 = plt.subplots(num=2, figsize=(2.8, 2.3), dpi=300)
    # 创建第三张图：x,bx,by
    fig3, ax3 = plt.subplots(num=3, figsize=(2.7, 1.2), dpi=300)

    # 流形图初始化
    a = np.arange(0, 500, 1)
    b = np.arange(0, 500, 1)
    X, Y = np.meshgrid(a, b)
    # 流形图每个点的速度
    U = base[0] + (para_a[0] * (I / ki[0]) / (1 + I / ki[0])) / (1 + (Y / k[1]) ** n[1]) - para_d[0] * X
    V = base[1] + (para_a[1] * (I / ki[1]) / (1 + I / ki[1])) / (1 + (X / k[0]) ** n[0]) - para_d[1] * Y

    # 跑时序轨迹
    y, dydt, br = edde(propensity_fcnpro, propensity_fcn, delay, tend, dt, k, ki, base, para_a, para_d, I)
    if y[-1, 0] > y[-1, 1]:
        print("X high")
    x = y[:-1, :]
    br = br[:-1, :]

    # 绘制第一张图：t-xy图
    ax1.plot(tint * 0.02 / np.log(2), y[:, 0], label="X")
    ax1.plot(tint * 0.02 / np.log(2), y[:, 1], label="Y")

    # 绘制第二张图：相图
    ax2.streamplot(X, Y, U, V, density=0.8, linewidth=0.6, color='lightskyblue', zorder=0)
    colors = plt.cm.viridis_r(np.linspace(0, 1, 100))
    points = np.array([x[:, 0], x[:, 1]]).T
    segments = np.hstack((points[:-1].reshape(-1, 2), points[1:].reshape(-1, 2))).reshape(-1, 2, 2)
    lc = LineCollection(segments, cmap='viridis_r', norm=LogNorm(vmin=0.1, vmax=tend * 0.02 / np.log(2)), linewidth=4,
                        zorder=1)
    lc.set_array(tint * 0.02 / np.log(2))
    ax2.add_collection(lc)
    ax2.scatter(28.8966, 424.515, marker='*', s=80, color='r', label="$fixedpoint:a=15$")  # 不动点delay
    ax2.scatter(424.515, 28.8966, marker='*', s=80, color='r', label="$fixedpoint:a=15$")  # 不动点delay
    # ax2.scatter(18.0555,665.293,marker='*',s=80,color='r',label="$fixedpoint:a=15$")#不动点a=15,13
    # ax2.scatter(557.885,26.2249,marker='*',s=80,color='r',label="$fixedpoint:a=15$")#不动点a=15,13
    # ax2.scatter(30.4292, 421.024,marker='*',s=80,color='r',label="$fixedpoint:a=15$")#不动点ki=0.05,0.1
    # ax2.scatter(450.231, 26.3694,marker='*',s=80,color='r',label="$fixedpoint:a=15$")#不动点ki=0.05,0.1
    # ax2.scatter(28.3796,445.697,marker='*',s=80,color='r',label="$fixedpoint:a=15$")#不动点ki=0.025,0.05
    # ax2.scatter(461.028,26.3973,marker='*',s=80,color='r',label="$fixedpoint:a=15$")#不动点ki=0.025,0.05

    # 绘制第三张图：x,bx,by
    ax3.plot(x[:, 0], br[:, 0], color='#1f77b4', linewidth=1, label="x")
    ax3.plot(x[:, 0], br[:, 1], color='#ff7f0e', linewidth=1, label="y")
    ax3.plot(x[:, 0], np.abs(br[:, 1] - br[:, 0]), color='#e50000', linewidth=1, label="delta")

    # 设置轴标签和范围
    ax1.set_xlabel('t')
    ax1.set_ylabel('Molecules')
    ax1.set_xlim(0, tend * 0.02 / np.log(2))
    ax1.set_ylim(0, 500)
    ax1.xaxis.set_major_locator(MaxNLocator(5))
    ax1.yaxis.set_major_locator(MaxNLocator(2))
    ax1.legend(loc='upper left', bbox_to_anchor=(1, 1))

    ax2.margins(0, 0)
    cbar = plt.colorbar(lc, ax=ax2)
    cbar.set_label('Time', rotation=270)
    ax2.set_xlabel("$x$")
    ax2.set_ylabel("$y$")
    ax2.set_xlim(0, 500)
    ax2.set_ylim(0, 500)
    ax2.xaxis.set_major_locator(MaxNLocator(5))
    ax2.yaxis.set_major_locator(MaxNLocator(5))

    ax3.set_xlim(0, 500)
    ax3.set_ylim(0, 20)
    ax3.xaxis.set_major_locator(MaxNLocator(5))
    ax3.yaxis.set_major_locator(MaxNLocator(2))
    ax3.set_xlabel('y')
    ax3.set_ylabel('production rate')
    # ax3.legend(loc='best')
    ax3.legend(loc='upper left', bbox_to_anchor=(1, 1))

    return fig1, fig2, fig3

#parameters
#时间
tend = 100*np.log(2)/0.02  # min
dt = 0.01*np.log(2)/0.02 #步长
itend=int(tend/dt) #步数

#initial
y = np.zeros(shape=(itend, 2))
dydt = np.zeros(shape=(itend, 2))
br = np.zeros(shape=(itend, 2))
tint = np.arange(itend)*dt

#参数
hist = np.array([0.001, 0])  # X, Y protein
para_a = np.array([10, 10])  #molecules/min
para_d = np.array([0.02, 0.02])  #min^-1
ki=np.array([0.025, 0.05])
base=np.array([0.1, 0.1])
I = 1.0
Tgradualinduction = 50*np.log(2)/0.02 #诱导需要50代达到终态
n = np.array([2, 2])

delay = np.array([0, 0.*np.log(2)/0.02]) #delay0是Y对X的调控，delay1是X对Y的调控，这里令X对Y的抑制更慢，即delay[0]<=delay[1]
idelay = np.array(delay/dt, dtype=np.int32) #每个dt对应的delay步数
k = np.array([100, 100])

#出图
#stepinduction/gradualinduction
fig1,fig2,fig3=plot_productionrate(gradualinductionpro,gradualinduction,delay,tend,dt, k, ki, base, para_a, para_d, I)
fig1.savefig('txy.pdf')
fig2.savefig('phase.pdf')
fig3.savefig('rate.pdf')
plt.show()