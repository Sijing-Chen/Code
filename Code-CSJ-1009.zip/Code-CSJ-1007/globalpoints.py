import numpy as np
import cmath
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import random
import pandas as pd
from matplotlib import pyplot
from scipy.integrate import odeint
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.collections import LineCollection
from scipy.stats import norm
import seaborn as sns
from sklearn.mixture import GaussianMixture
from scipy.integrate import odeint
from matplotlib.backends.backend_pdf import PdfPages
from scipy.interpolate import RectBivariateSpline
import os
output_directory = './output'

#constant induction
def propensities_bistable(x, t, k, ki, base, para_a, para_d, I):
    X1 = x[0]
    X2 = x[1]
    n = [2, 2]
    a = [base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))/(1 + (X2/k[1])**n[1]),                # X1 production
         base[1] + (para_a[1]*(I/ki[1])/(1+I/ki[1]))/(1 + (X1/k[0])**n[0]),                # X2 production
         para_d[0]*X1,                                             # protein decay
         para_d[1]*X2]                                             # protein decay
    return a

#gradual induction
def propensities_bistable_gradualinduction(x, t, k, ki, base, para_a, para_d, I):
    Tgradualinduction = 50*np.log(2)/0.02 #诱导需要50代达到终态
    if t<=Tgradualinduction:
        I = I*t/Tgradualinduction

    X1 = x[0]
    X2 = x[1]
    n = [2, 2]
    a = [base[0] + (para_a[0]*(I/ki[0])/(1+I/ki[0]))/(1 + (X2/k[1])**n[1]),                # X1 production
         base[1] + (para_a[1]*(I/ki[1])/(1+I/ki[1]))/(1 + (X1/k[0])**n[0]),                # X2 production
         para_d[0]*X1,                                             # protein decay
         para_d[1]*X2]                                             # protein decay
    return a

#with delay
def direct_method_withdelay(propensity_fcn, tspan, x0, delay, k, ki, base, para_a, para_d, I):
    # Initialize
    stoich_matrix = np.array([[1, 0],  # X1 production
                              [0, 1],  # X2 production
                              [-1, 0],  # X1 decay
                              [0, -1]])  # X2 decay
    num_species = stoich_matrix.shape[1]
    MAX_OUTPUT_LENGTH = round(tspan[1]*0.02/np.log(2)*2000)
    T = np.zeros(MAX_OUTPUT_LENGTH)
    X = np.zeros((MAX_OUTPUT_LENGTH, num_species))
    td = np.zeros(MAX_OUTPUT_LENGTH)
    mu = np.zeros(MAX_OUTPUT_LENGTH)
    T[0] = tspan[0]
    X[0, :] = x0
    window_size = round(delay[1] / 0.01)  # Define window size

    # Main loop
    rxn_count = 1

    while T[rxn_count - 1] < tspan[1]:

        if rxn_count >= MAX_OUTPUT_LENGTH:
            t = T[:rxn_count - 1]
            x = X[:rxn_count - 1, :]
            print('Number of reaction events exceeded the number pre-allocated. Simulation terminated prematurely.')
            return t, x

        a = propensity_fcn(X[rxn_count - 1, :], T[rxn_count - 1], k, ki, base, para_a, para_d, I)
        a0 = np.sum(a)
        u = np.random.rand(2)
        tau = -np.log(u[0]) / a0

        # Check whether there are delayed reactions scheduled within time interval
        # Define the window for td
        start_index = max(0, rxn_count - window_size)
        end_index = rxn_count

        ind = (td[start_index:end_index] > T[rxn_count - 1]) & (td[start_index:end_index] <= T[rxn_count - 1] + tau)
        mintd = np.min(td[start_index:end_index][ind]) if np.any(ind) else None

        if mintd:
            T[rxn_count] = mintd
            X[rxn_count, :] = X[rxn_count - 1, :] + stoich_matrix[1, :]
            rxn_count += 1
            continue

        mu[rxn_count] = np.digitize(u[1] * a0, np.cumsum(a))

        if mu[rxn_count] == 1:
            td[rxn_count] = T[rxn_count - 1] + delay[1]
            X[rxn_count, :] = X[rxn_count - 1, :]
            T[rxn_count] = T[rxn_count - 1] + tau
            rxn_count += 1
            continue

        # Update time and carry out reaction mu
        T[rxn_count] = T[rxn_count - 1] + tau
        X[rxn_count, :] = X[rxn_count - 1, :] + stoich_matrix[int(mu[rxn_count]), :]
        rxn_count += 1

    # Return simulation time course
    t = T[:rxn_count - 1]
    x = X[:rxn_count - 1, :]
    # print(rxn_count)
    if t[-1] > tspan[1]:
        t[-1] = tspan[1]
        x[-1, :] = X[rxn_count - 1, :]

    return t, x

#without delay
def direct_method_withoutdelay(propensity_fcn, tspan, x0, delay, k, ki, base, para_a, para_d, I):
    # Initialize
    stoich_matrix = np.array([[1, 0],  # X1 production
                              [0, 1],  # X2 production
                              [-1, 0],  # X1 decay
                              [0, -1]])  # X2 decay
    num_species = stoich_matrix.shape[1]
    MAX_OUTPUT_LENGTH = round(tspan[1]*0.02/np.log(2)*1000)
    T = np.zeros(MAX_OUTPUT_LENGTH)
    X = np.zeros((MAX_OUTPUT_LENGTH, num_species))
    mu = np.zeros(MAX_OUTPUT_LENGTH)
    T[0] = tspan[0]
    X[0, :] = x0

    # Main loop
    rxn_count = 1
    while T[rxn_count - 1] < tspan[1]:

        if rxn_count >= MAX_OUTPUT_LENGTH:
            t = T[:rxn_count - 1]
            x = X[:rxn_count - 1, :]
            print('Number of reaction events exceeded the number pre-allocated. Simulation terminated prematurely.')
            return t, x

        a = propensity_fcn(X[rxn_count - 1, :], T[rxn_count - 1], k, ki, base, para_a, para_d, I)
        a0 = np.sum(a)
        u = np.random.rand(2)
        tau = -np.log(u[0]) / a0

        mu[rxn_count] = np.digitize(u[1] * a0, np.cumsum(a))

        # Update time and carry out reaction mu
        T[rxn_count] = T[rxn_count - 1] + tau
        X[rxn_count, :] = X[rxn_count - 1, :] + stoich_matrix[int(mu[rxn_count]), :]
        rxn_count += 1

    # Return simulation time course
    t = T[:rxn_count - 1]
    x = X[:rxn_count - 1, :]
    # print(rxn_count)
    if t[-1] > tspan[1]:
        t[-1] = tspan[1]
        x[-1, :] = X[rxn_count - 1, :]

    return t, x

#final_position
def probability_distribution(tspan, delay, k, ki, base, para_a, para_d, I):
    # 初始化列表
    final_positions = []
    count_x_greater_than_y = 0
    count_path = 0

    # 生成轨迹并记录最终位置
    for x0 in range(0, 801, 10):  # 每隔10取一个点，共81*81=6561条轨迹
        for y0 in range(0, 801, 10):

            x_initial = np.array([x0, y0])
            t, x = direct_method_withdelay(propensities_bistable, tspan, x_initial, delay, k, ki, base, para_a, para_d, I)

            # 记录最终位置
            final_position = x[-1, :]
            final_positions.append(final_position)

            # 判断 x 是否大于 y
            if final_position[0] > final_position[1]:
                count_x_greater_than_y += 1
            count_path += 1
        print(count_path)

    # 最终位置
    final_positions = np.array(final_positions)
    txt = 'X high: {}/{}'.format(count_x_greater_than_y, count_path)
    print(txt)

    return final_positions

#parameters
para_d = np.array([0.02, 0.02])  #min^-1
base = np.array([0.1, 0.1])
I = 1.0
n = [2, 2]
k = [100, 100]
#主要改
tspan = [0, 100*np.log(2)/0.02]  # min
para_a = np.array([13, 15])  #molecules/min
ki = np.array([0.1, 0.1])
delay = [0, 0.5*np.log(2)/0.02]

#全局撒点稳态pdf，默认使用withoutdelay、台阶诱导
final_positions=probability_distribution(tspan, delay, k, ki, base, para_a, para_d, I)
#保存final_positions
FP=pd.DataFrame(final_positions)
file_path= os.path.join(output_directory, 'a1315de05_finalpositions.xlsx')
writer=pd.ExcelWriter(file_path)
FP.to_excel(excel_writer=writer, sheet_name='sheet1', float_format='%.5f')
#writer.save()
writer.close()
